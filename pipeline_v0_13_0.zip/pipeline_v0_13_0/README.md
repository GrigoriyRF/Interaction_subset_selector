# Пайплайн подготовки выборок и отбора факторов — v0.13.0

Комплект состоит из двух согласованных блоков:

1. `prepare_selector_samples.py` формирует train/valid/OOS/OOT/test, фолды и
   машинно-читаемые манифесты.
2. `interaction_subset_selector.py` отбирает компактный набор факторов с учётом
   взаимодействий. `run_stability_selection.py` повторяет отбор на фолдах и
   агрегирует устойчивость факторов.

Для запуска из Jupyter используйте `run_pipeline.ipynb`. Прямой запуск одного
селектора выполняется через `run_interaction_selector.py`; он не содержит
собственных настроек и всегда использует переданный YAML как единственный
источник конфигурации.

## Что изменено в 0.13.0

- Полностью удалено ограничение разрыва GINI между train и valid. `train_gini`,
  `valid_gini` и `gini_gap` сохраняются только как диагностические показатели и
  не влияют на `constraint_violation`, Pareto-front или выбор победителя.
- Поле `search.max_gap` заменено однозначным
  `search.max_primary_metric_gap`. Оно относится только к основной метрике и
  может быть отключено значением `null`.
- Поле `decision_threshold.require_oos_feasible` заменено на
  `decision_threshold.oos_policy` (`report`, `filter` или `strict`).
- Исправлено распределение GPU: решение о допуске воркера и выборе устройства
  принимается по одному снимку ресурсов. Устранён конфликт повторной проверки,
  который приводил к `no safe isolated-worker slot`.
- Референсный baseline ограничен `search_max_features`, поэтому калибровка на
  100 факторах больше не сменяется неожиданным baseline на всей тысяче факторов.
- Хэш исходного кода селектора и stability-runner включён в fingerprint. После
  изменения кода старые кэши и маркеры resume не считаются совместимыми.
- Notebook проверяет контракт существующих `split_parts`, сохраняет групповые
  ключи в `leakage_key_columns`, корректно задаёт GPU для Ray и запускает прямой
  режим через единый валидирующий runner.
- Категориальные null заполняются значением
  `data.categorical_null_value` непосредственно перед передачей данных CatBoost.

## Быстрый запуск

Скопируйте example-конфиги без суффикса `.example`, заполните пути и параметры:

```bash
python prepare_selector_samples.py --config config.sample-preprocessing.yaml
python run_interaction_selector.py --config config.interaction-selector.yaml
```

Для stability selection:

```bash
python run_stability_selection.py --config config.stability-selection.yaml
```

Проверить конфиг и ресурсный план без обучения:

```bash
python run_interaction_selector.py \
  --config config.interaction-selector.yaml \
  --plan-only
```

## Миграция конфигурации

```yaml
search:
  # null — не ограничивать train/valid gap основной метрики
  max_primary_metric_gap: null

decision_threshold:
  oos_policy: report
  enforce_during_search: false
```

Параметра `max_gini_gap` в 0.13.0 нет. Добавлять его в YAML не нужно.

## Проверки

```bash
python test_prepare_selector_samples.py
python test_run_stability_selection.py
python test_interaction_subset_selector.py
```

Полный синтетический E2E-тест (требует CatBoost, Polars и PyArrow):

```bash
python e2e_interaction_subset_selector.py
```
