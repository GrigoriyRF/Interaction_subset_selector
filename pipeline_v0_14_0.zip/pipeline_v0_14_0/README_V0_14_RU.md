# Interaction subset selector 0.14.0

Версия собрана на основе последних загруженных файлов проекта. Главное изменение — явное обучение коалиций факторов до четвёртого порядка.

## Что изменилось

- `coalition_max_order` управляет максимальным порядком коалиций: `2`, `3` или `4`.
- Пары и тройки обучаются по истории полностью оценённых комбинаций.
- Четвёрки строятся только расширением сильных троек. Полного перебора четвёрок нет.
- Найденные четвёрки участвуют в генерации, мутации и сохранении перспективных комбинаций наравне с парами и тройками.
- Новые параметры входят в fingerprint. Несовместимый старый checkpoint автоматически игнорируется.
- Notebook пишет результаты 0.14.0 в отдельные каталоги `interaction_selection_results_v14` и `stability_selection_v14`.

## Новые параметры

```yaml
search:
  coalition_max_order: 4
  coalition_top_pairs: 200
  coalition_top_triples: 40
  coalition_top_quads: 20
  coalition_quad_parent_triples: 100
  coalition_pairs_per_subset: 2000
  coalition_triples_per_subset: 200
  coalition_quads_per_subset: 100
```

`coalition_quad_parent_triples` ограничивает число сильных троек, которые разрешено расширять до четвёрок. `coalition_quads_per_subset` ограничивает число четвёрок, учитываемых из одной оценённой комбинации.

## Практические режимы

Для stability selection на широкой исходной вселенной факторов используйте значения шаблона. Они удерживают стоимость четвёрок под контролем.

Для отдельного финального поиска на небольшом candidate pool, например на 34 факторах, бюджет можно увеличить:

```yaml
search:
  coalition_max_order: 4
  coalition_top_triples: 150
  coalition_top_quads: 75
  coalition_quad_parent_triples: 300
  coalition_triples_per_subset: 6000
  coalition_quads_per_subset: 1000
```

Увеличение этих бюджетов усиливает исследование синергий, но не заставляет итоговую модель содержать больше факторов. За допустимое сокращение качества ради компактности отдельно отвечает `search.allowed_metric_drop`.

## Запуск

Основной сценарий — `run_pipeline.ipynb`. Старые результаты 0.13.0 удалять не требуется.

Для проверки без обучения:

```bash
python interaction_subset_selector.py --config config.interaction-selector.yaml --plan-only
```

Для запуска selector:

```bash
python interaction_subset_selector.py --config config.interaction-selector.yaml
```

## Проверки

Для версии добавлен unit-тест, подтверждающий, что сильная четвёрка действительно восстанавливается через устойчивые тройки. Полный набор тестов запускается командой:

```bash
python -m unittest -v \
  test_interaction_subset_selector.py \
  test_run_stability_selection.py \
  test_prepare_selector_samples.py
```
