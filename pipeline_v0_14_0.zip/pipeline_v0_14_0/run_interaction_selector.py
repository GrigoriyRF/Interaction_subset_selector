#!/usr/bin/env python3
"""Validated CLI runner for interaction_subset_selector 0.13.x.

The supplied YAML is the single source of truth for data, model, search and
resource settings.  This runner only validates the effective configuration,
prints a compact execution plan and starts the selector.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

from interaction_subset_selector import run_pipeline, run_preflight


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run interaction subset selection from one YAML config."
    )
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument(
        "--plan-only",
        action="store_true",
        help="Validate inputs and print the plan without training models.",
    )
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    config_path = args.config.expanduser().resolve()
    if not config_path.is_file():
        raise FileNotFoundError(f"Config file does not exist: {config_path}")

    plan = run_preflight(config_path)
    summary = {
        key: plan.get(key)
        for key in (
            "selector_version",
            "validation_mode",
            "active_splits",
            "input_features",
            "execution",
            "warnings",
        )
        if key in plan
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2, default=str))

    if args.plan_only:
        return 0

    run_pipeline(config_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
