# Tabular Preprocessor

Polars-native конвейер подготовки табличных данных. Он читает CSV, Parquet и
Arrow IPC лениво, определяет роли признаков, формирует выборки, обучает
преобразования только на `train`, применяет единый state ко всем выборкам и
записывает результат Parquet-партициями.

## Установка и запуск

```bash
pip install -e .
tabular-preprocessor examples/config.py
```

Если сервер не имеет доступа к PyPI и не может скачать `hatchling`, установите
готовый wheel без сборки:

```bash
pip install --no-deps tabular_preprocessor-0.1.0-py3-none-any.whl
tabular-preprocessor examples/config.py
```

Ключ `--no-deps` предполагает, что `polars>=1.44` уже установлен в окружении.
Без установки пакета проект можно запустить непосредственно из исходников:

```bash
PYTHONPATH=src python -m tabular_preprocessor.cli examples/config.py
```

Конфигурационный модуль должен экспортировать объект `CONFIG` типа
`ProjectConfig`. Программный запуск:

```python
from tabular_preprocessor import Pipeline
from config import CONFIG

result = Pipeline(CONFIG).run()
print(result.manifest_path)
```

Результат содержит каталоги `data`, `state`, `reports` и файл `manifest.json`.
Повторное применение рассчитанного состояния выполняется через
`Pipeline.from_state(CONFIG, "output/state/pipeline_state.json").transform(...)`.

## Границы MVP

Включены основные стратегии числовых, категориальных, временных и текстовых
преобразований. Cross-fit target encoding, сложная импутация, HTML-отчёт и
полный набор drift-метрик относятся к следующим версиям.
