from tabular_preprocessor.config import (
    CategoricalConfig,
    InputConfig,
    NumericConfig,
    OutputConfig,
    ProjectConfig,
    SchemaConfig,
    SplitConfig,
    TaskConfig,
)

CONFIG = ProjectConfig(
    input=InputConfig(paths=("data/*.parquet",)),
    task=TaskConfig(
        target="target",
        task_type="binary",
        id_columns=("customer_id",),
        date_column="event_date",
    ),
    output=OutputConfig(
        path="prepared_data",
        partition_columns=("sample",),
        rows_per_file=500_000,
    ),
    schema=SchemaConfig(
        explicit_roles={"region": "categorical"},
        role_patterns={r".*_flag$": "binary"},
        required_columns=("customer_id", "event_date", "target"),
    ),
    split=SplitConfig(
        method="temporal",
        allowed_samples=("train", "valid", "test"),
        boundaries=("2024-12-31", "2025-03-31"),
    ),
    numeric=NumericConfig(scaling="robust", winsorize=(0.01, 0.99)),
    categorical=CategoricalConfig(default_strategy="native", rare_min_fraction=0.001),
)

