import polars as pl

from ..config import ProjectConfig


def check_quality(lf: pl.LazyFrame, config: ProjectConfig) -> list[dict]:
    if not config.leakage.enabled:
        return []
    issues: list[dict] = []
    sample = config.split.sample_column
    schema = lf.collect_schema()
    counts = lf.select(pl.len().alias("rows"), *[pl.col(c).n_unique().alias(c) for c in schema]).collect().row(0, named=True)
    for c in schema:
        if counts[c] <= 1:
            issues.append(_issue("constant", "warning", c, "constant column", "exclude column"))
        elif counts[c] / counts["rows"] >= config.leakage.near_constant_fraction and c not in config.task.id_columns:
            issues.append(_issue("possible_id", "warning", c, "almost every value is unique", "review role"))

    target = config.task.target
    if target and target in schema:
        candidates = [c for c in schema if c not in {target, sample} and schema[c] == schema[target]]
        if candidates:
            equal = lf.select([(pl.col(c) == pl.col(target)).fill_null(False).all().alias(c) for c in candidates]).collect().row(0, named=True)
            for c, copied in equal.items():
                if copied:
                    issues.append(_issue("target_copy", "critical", c, "exact copy of target", "exclude column"))

    if sample in schema:
        for id_column in config.task.id_columns:
            overlap = lf.group_by(id_column).agg(pl.col(sample).n_unique().alias("n")).filter(pl.col("n") > 1).select(pl.len()).collect().item()
            if overlap:
                issues.append(_issue("sample_overlap", "critical", id_column, f"{overlap} IDs occur in several samples", "use grouped split"))
    return issues


def _issue(check: str, severity: str, column: str, reason: str, action: str) -> dict:
    return {"check": check, "severity": severity, "column": column, "sample": None, "reason": reason, "recommended_action": action}

