from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

Role = Literal[
    "numeric", "categorical", "ordinal", "binary", "datetime", "text",
    "id", "target", "technical", "excluded", "unknown",
]


@dataclass(frozen=True)
class InputConfig:
    paths: tuple[str, ...]
    format: Literal["parquet", "csv", "ipc"] = "parquet"
    columns: tuple[str, ...] | None = None
    row_index: str | None = None
    csv_separator: str = ","


@dataclass(frozen=True)
class TaskConfig:
    target: str | None = None
    task_type: Literal["binary", "multiclass", "regression", "unsupervised"] = "unsupervised"
    id_columns: tuple[str, ...] = ()
    date_column: str | None = None
    excluded_columns: tuple[str, ...] = ()


@dataclass(frozen=True)
class OutputConfig:
    path: str
    format: Literal["parquet"] = "parquet"
    partition_columns: tuple[str, ...] = ("sample",)
    compression: str = "zstd"
    rows_per_file: int = 1_000_000
    overwrite: bool = False


@dataclass(frozen=True)
class SchemaConfig:
    explicit_roles: dict[str, Role] = field(default_factory=dict)
    role_patterns: dict[str, Role] = field(default_factory=dict)
    required_columns: tuple[str, ...] = ()
    nullable: dict[str, bool] = field(default_factory=dict)
    ranges: dict[str, tuple[float | None, float | None]] = field(default_factory=dict)
    allowed_values: dict[str, tuple[object, ...]] = field(default_factory=dict)
    casts: dict[str, str] = field(default_factory=dict)
    string_text_length: int = 80


@dataclass(frozen=True)
class ProfilingConfig:
    enabled: bool = True
    sample_rows: int | None = 1_000_000
    quantiles: tuple[float, ...] = (0.01, 0.25, 0.5, 0.75, 0.99)
    top_k: int = 10


@dataclass(frozen=True)
class SplitConfig:
    method: Literal["none", "existing", "random", "stratified", "group", "temporal", "group_temporal"] = "none"
    sample_column: str = "sample"
    allowed_samples: tuple[str, ...] = ("train", "valid", "test")
    fractions: tuple[float, ...] = (0.7, 0.15, 0.15)
    group_column: str | None = None
    date_column: str | None = None
    boundaries: tuple[str, ...] = ()
    seed: int = 42


@dataclass(frozen=True)
class MissingConfig:
    numeric: Literal["median", "mean", "zero", "none"] = "median"
    categorical: Literal["most_frequent", "constant", "none"] = "constant"
    categorical_value: str = "__MISSING__"
    text_value: str = ""
    add_indicator: bool = True


@dataclass(frozen=True)
class NumericConfig:
    dtype: Literal["float32", "float64"] = "float32"
    scaling: Literal["none", "standard", "robust"] = "none"
    winsorize: tuple[float, float] | None = None
    clip: dict[str, tuple[float | None, float | None]] = field(default_factory=dict)
    log1p: tuple[str, ...] = ()
    quantile_bins: dict[str, int] = field(default_factory=dict)


@dataclass(frozen=True)
class CategoricalConfig:
    default_strategy: Literal["native", "ordinal", "frequency", "one_hot"] = "native"
    overrides: dict[str, Literal["native", "ordinal", "frequency", "one_hot"]] = field(default_factory=dict)
    normalize_case: bool = True
    strip: bool = True
    rare_min_fraction: float = 0.0
    max_one_hot_categories: int = 20


@dataclass(frozen=True)
class DatetimeConfig:
    components: tuple[str, ...] = ("year", "month", "weekday")
    cyclical: tuple[str, ...] = ()
    drop_original: bool = False


@dataclass(frozen=True)
class TextConfig:
    enabled: bool = True
    features: tuple[str, ...] = ("length", "words", "digit_ratio", "special_count", "is_empty")
    drop_original: bool = True


@dataclass(frozen=True)
class LeakageConfig:
    enabled: bool = True
    near_constant_fraction: float = 0.995


@dataclass(frozen=True)
class DriftConfig:
    enabled: bool = False
    reference_sample: str = "train"
    comparison_samples: tuple[str, ...] = ("valid", "test", "oot")
    warning: float = 0.10
    critical: float = 0.25


@dataclass(frozen=True)
class ResourceConfig:
    threads: int | None = None
    memory_limit_gb: float | None = None


@dataclass(frozen=True)
class ReportingConfig:
    enabled: bool = True


@dataclass(frozen=True)
class ProjectConfig:
    input: InputConfig
    task: TaskConfig
    output: OutputConfig
    schema: SchemaConfig = field(default_factory=SchemaConfig)
    profiling: ProfilingConfig = field(default_factory=ProfilingConfig)
    split: SplitConfig = field(default_factory=SplitConfig)
    missing: MissingConfig = field(default_factory=MissingConfig)
    numeric: NumericConfig = field(default_factory=NumericConfig)
    categorical: CategoricalConfig = field(default_factory=CategoricalConfig)
    datetime: DatetimeConfig = field(default_factory=DatetimeConfig)
    text: TextConfig = field(default_factory=TextConfig)
    leakage: LeakageConfig = field(default_factory=LeakageConfig)
    drift: DriftConfig = field(default_factory=DriftConfig)
    resources: ResourceConfig = field(default_factory=ResourceConfig)
    reporting: ReportingConfig = field(default_factory=ReportingConfig)

    def validate(self) -> None:
        if not self.input.paths:
            raise ValueError("input.paths is empty")
        if self.output.rows_per_file < 1:
            raise ValueError("output.rows_per_file must be positive")
        if self.split.method in {"random", "stratified", "group"}:
            if len(self.split.fractions) != len(self.split.allowed_samples):
                raise ValueError("split.fractions and allowed_samples must have equal length")
            if abs(sum(self.split.fractions) - 1) > 1e-9:
                raise ValueError("split.fractions must sum to 1")
        if self.split.method in {"group", "group_temporal"} and not self.split.group_column:
            raise ValueError("group_column is required")
        if self.split.method in {"temporal", "group_temporal"}:
            if not (self.split.date_column or self.task.date_column):
                raise ValueError("date_column is required")
            if len(self.split.boundaries) != len(self.split.allowed_samples) - 1:
                raise ValueError("temporal boundaries count must be samples count minus one")
        if self.split.method == "stratified" and not self.task.target:
            raise ValueError("target is required for stratified split")
        if Path(self.output.path).resolve() in {Path("/").resolve(), Path.home().resolve()}:
            raise ValueError("unsafe output path")

