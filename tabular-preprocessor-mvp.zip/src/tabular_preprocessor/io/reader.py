from glob import glob
from pathlib import Path

import polars as pl

from ..config import InputConfig


def _paths(config: InputConfig) -> list[str]:
    suffix = {"parquet": "*.parquet", "csv": "*.csv", "ipc": "*.ipc"}[config.format]
    found: list[str] = []
    for raw in config.paths:
        path = Path(raw)
        found.extend(str(p) for p in sorted(path.rglob(suffix)) if path.is_dir())
        if not path.is_dir():
            found.extend(sorted(glob(raw, recursive=True)))
    return list(dict.fromkeys(found))


def read_lazy(config: InputConfig, data: pl.DataFrame | pl.LazyFrame | None = None) -> pl.LazyFrame:
    if data is not None:
        lf = data.lazy() if isinstance(data, pl.DataFrame) else data
    else:
        paths = _paths(config)
        if not paths:
            raise FileNotFoundError(f"No {config.format} files found: {config.paths}")
        if config.format == "parquet":
            lf = pl.scan_parquet(paths)
        elif config.format == "csv":
            lf = pl.scan_csv(paths, separator=config.csv_separator)
        else:
            lf = pl.scan_ipc(paths)
    if config.columns:
        lf = lf.select(config.columns)
    if config.row_index:
        lf = lf.with_row_index(config.row_index)
    return lf

