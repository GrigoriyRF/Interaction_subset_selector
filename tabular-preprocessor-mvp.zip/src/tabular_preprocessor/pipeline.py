import json
import shutil
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from hashlib import sha256
from pathlib import Path

import polars as pl

from .checks import check_quality
from .config import ProjectConfig
from .io.reader import read_lazy
from .io.writer import commit, staging_directory, write_dataset
from .profiling import profile
from .reports import save_reports
from .schema import infer_roles, validate_schema
from .splitting import split
from .transformations import PipelineState, fit, transform


@dataclass(frozen=True)
class RunResult:
    output_path: Path
    manifest_path: Path
    state_path: Path
    rows: int
    files: int


class Pipeline:
    def __init__(self, config: ProjectConfig, state: PipelineState | None = None):
        config.validate()
        self.config = config
        self.state = state

    @classmethod
    def from_state(cls, config: ProjectConfig, path: str | Path) -> "Pipeline":
        return cls(config, PipelineState.load(path))

    def prepare(self, data: pl.DataFrame | pl.LazyFrame | None = None) -> tuple[pl.LazyFrame, dict, pl.DataFrame, list[dict]]:
        lf, schema_issues = validate_schema(read_lazy(self.config.input, data), self.config.schema, self.config.task)
        roles = infer_roles(lf, self.config.schema, self.config.task)
        summary, column_profile = profile(lf, roles, self.config.profiling) if self.config.profiling.enabled else ({}, pl.DataFrame())
        sampled = split(lf, self.config.split, self.config.task)
        train_name = "train" if "train" in self.config.split.allowed_samples else self.config.split.allowed_samples[0]
        train = sampled.filter(pl.col(self.config.split.sample_column) == train_name)
        if train.select(pl.len()).collect().item() == 0:
            raise ValueError(f"Reference sample is empty: {train_name}")
        self.state = fit(train, roles, self.config)
        prepared = transform(sampled, self.state, self.config)
        self.state.output_schema = {k: str(v) for k, v in prepared.collect_schema().items()}
        return prepared, summary, column_profile, schema_issues + check_quality(sampled, self.config)

    def transform(self, data: pl.DataFrame | pl.LazyFrame) -> pl.LazyFrame:
        if self.state is None:
            raise RuntimeError("Pipeline is not fitted")
        lf, _ = validate_schema(read_lazy(self.config.input, data), self.config.schema, self.config.task)
        return transform(lf, self.state, self.config)

    def run(self, data: pl.DataFrame | pl.LazyFrame | None = None) -> RunResult:
        output, stage = staging_directory(self.config.output)
        try:
            prepared, summary, column_profile, issues = self.prepare(data)
            files = write_dataset(prepared, stage, self.config.output)
            self._save_state(stage / "state")
            if self.config.reporting.enabled:
                save_reports(stage / "reports", summary, column_profile, issues)
            manifest = self._manifest(files, summary, issues)
            (stage / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
            commit(output, stage, self.config.output.overwrite)
        except Exception:
            shutil.rmtree(stage, ignore_errors=True)
            raise
        return RunResult(output, output / "manifest.json", output / "state/pipeline_state.json", manifest["rows"], len(files))

    def _save_state(self, path: Path) -> None:
        path.mkdir(parents=True)
        self.state.save(path / "pipeline_state.json")
        for name, value in (
            ("input_schema.json", self.state.input_schema),
            ("output_schema.json", self.state.output_schema),
            ("feature_roles.json", self.state.roles),
        ):
            (path / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
        numeric_rows = [{"column": c, **v, "bins": json.dumps(v["bins"])} for c, v in self.state.numeric.items()]
        category_rows = [{"column": c, **v, "known": json.dumps(v["known"], ensure_ascii=False), "mapping": json.dumps(v["mapping"], ensure_ascii=False), "frequencies": json.dumps(v["frequencies"], ensure_ascii=False)} for c, v in self.state.categorical.items()]
        pl.DataFrame(numeric_rows).write_parquet(path / "numeric_statistics.parquet")
        pl.DataFrame(category_rows).write_parquet(path / "category_mappings.parquet")
        transforms = [{"column": c, "role": role, "transformation": self._transformation(c, role)} for c, role in self.state.roles.items()]
        pl.DataFrame(transforms).write_parquet(path / "transformations.parquet")
        (path / "transform_log.json").write_text(json.dumps(transforms, ensure_ascii=False, indent=2), encoding="utf-8")

    def _manifest(self, files: list[dict], summary: dict, issues: list[dict]) -> dict:
        raw_config = json.dumps(asdict(self.config), ensure_ascii=False, sort_keys=True, default=str)
        return {
            "status": "success", "pipeline_version": self.state.version,
            "created_at": datetime.now(UTC).isoformat(), "config_sha256": sha256(raw_config.encode()).hexdigest(),
            "rows": sum(f["rows"] for f in files), "files": files,
            "input_summary": summary, "issues": {s: sum(i["severity"] == s for i in issues) for s in ("critical", "warning", "info")},
            "partition_columns": list(self.config.output.partition_columns), "output_schema": self.state.output_schema,
        }

    def _transformation(self, column: str, role: str) -> str:
        if role == "numeric":
            return "numeric"
        if role in {"categorical", "ordinal", "binary"}:
            return self.state.categorical.get(column, {}).get("strategy", "native")
        if role == "datetime":
            return "datetime_components"
        if role == "text":
            return "text_statistics"
        return "passthrough"

