import json

import polars as pl

from ..config import ProfilingConfig


def profile(lf: pl.LazyFrame, roles: dict[str, str], config: ProfilingConfig) -> tuple[dict, pl.DataFrame]:
    total_rows = lf.select(pl.len()).collect().item()
    sampled = lf.limit(config.sample_rows) if config.sample_rows else lf
    df = sampled.collect(engine="streaming")
    rows = []
    for name in df.columns:
        s = df[name]
        non_null = s.drop_nulls()
        numeric = s.dtype.is_numeric()
        top = s.value_counts(sort=True).head(config.top_k).to_dicts()
        row = {
            "column": name,
            "physical_type": str(s.dtype),
            "role": roles.get(name, "unknown"),
            "rows_profiled": len(s),
            "null_count": s.null_count(),
            "null_fraction": s.null_count() / len(s) if len(s) else 0.0,
            "n_unique": s.n_unique(),
            "constant": s.n_unique() <= 1,
            "min": float(non_null.min()) if numeric and len(non_null) else None,
            "max": float(non_null.max()) if numeric and len(non_null) else None,
            "mean": float(non_null.mean()) if numeric and len(non_null) else None,
            "std": float(non_null.std()) if numeric and len(non_null) > 1 else None,
            "top_values": json.dumps(top, ensure_ascii=False, default=str),
        }
        for q in config.quantiles:
            row[f"q_{q:g}"] = float(non_null.quantile(q)) if numeric and len(non_null) else None
        rows.append(row)
    summary = {
        "rows": total_rows,
        "columns": len(df.columns),
        "profiled_rows": len(df),
        "duplicate_rows_profiled": df.is_duplicated().sum(),
        "physical_types": {str(dtype): list(df.schema.values()).count(dtype) for dtype in set(df.schema.values())},
    }
    return summary, pl.DataFrame(rows)

