import json
from pathlib import Path

import polars as pl


def save_reports(path: Path, summary: dict, profile: pl.DataFrame, issues: list[dict]) -> None:
    path.mkdir(parents=True, exist_ok=True)
    (path / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    profile.write_parquet(path / "profile.parquet")
    schema = {
        "check": pl.String, "severity": pl.String, "column": pl.String,
        "sample": pl.String, "reason": pl.String, "recommended_action": pl.String,
    }
    pl.DataFrame(issues, schema=schema).write_parquet(path / "issues.parquet")

