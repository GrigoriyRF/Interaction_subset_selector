import math

import polars as pl

from ..config import ProjectConfig
from .state import PipelineState


def _category(expr: pl.Expr, config: ProjectConfig) -> pl.Expr:
    expr = expr.cast(pl.String, strict=False)
    if config.categorical.strip:
        expr = expr.str.strip_chars()
    if config.categorical.normalize_case:
        expr = expr.str.to_lowercase()
    return expr


def fit(train: pl.LazyFrame, roles: dict[str, str], config: ProjectConfig) -> PipelineState:
    schema = train.collect_schema()
    state = PipelineState(roles=roles, input_schema={k: str(v) for k, v in schema.items()})
    numeric = [c for c, role in roles.items() if role == "numeric" and c in schema]
    if numeric:
        expressions = []
        for c in numeric:
            x = pl.col(c).cast(pl.Float64, strict=False).replace([math.inf, -math.inf], None)
            expressions.extend([
                x.mean().alias(f"{c}__mean"), x.median().alias(f"{c}__median"),
                x.std().alias(f"{c}__std"), x.quantile(.25).alias(f"{c}__q25"),
                x.quantile(.75).alias(f"{c}__q75"),
            ])
            if config.numeric.winsorize:
                lo, hi = config.numeric.winsorize
                expressions.extend([x.quantile(lo).alias(f"{c}__lo"), x.quantile(hi).alias(f"{c}__hi")])
            for i, q in enumerate(j / config.numeric.quantile_bins[c] for j in range(1, config.numeric.quantile_bins.get(c, 1))):
                expressions.append(x.quantile(q).alias(f"{c}__bin_{i}"))
        row = train.select(expressions).collect()
        for c in numeric:
            mean, median = row.item(0, f"{c}__mean"), row.item(0, f"{c}__median")
            q25, q75 = row.item(0, f"{c}__q25"), row.item(0, f"{c}__q75")
            fill = {"median": median, "mean": mean, "zero": 0.0, "none": None}[config.missing.numeric]
            if config.numeric.scaling == "standard":
                center, scale = mean, row.item(0, f"{c}__std")
            elif config.numeric.scaling == "robust":
                center, scale = median, (q75 - q25 if q75 is not None and q25 is not None else None)
            else:
                center, scale = 0.0, 1.0
            clip = config.numeric.clip.get(c, (None, None))
            if config.numeric.winsorize:
                clip = (row.item(0, f"{c}__lo"), row.item(0, f"{c}__hi"))
            bins = [row.item(0, f"{c}__bin_{i}") for i in range(max(config.numeric.quantile_bins.get(c, 1) - 1, 0))]
            state.numeric[c] = {"fill": fill, "center": center, "scale": scale or 1.0, "lower": clip[0], "upper": clip[1], "bins": bins}

    categorical = [c for c, role in roles.items() if role in {"categorical", "ordinal", "binary"} and c in schema]
    if categorical:
        df = train.select([_category(pl.col(c), config).alias(c) for c in categorical]).collect(engine="streaming")
        for c in categorical:
            s = df[c]
            fill = config.missing.categorical_value
            if config.missing.categorical == "most_frequent" and len(s.drop_nulls()):
                fill = s.drop_nulls().mode()[0]
            normalized = s.fill_null(fill) if config.missing.categorical != "none" else s
            counts = normalized.value_counts(sort=True)
            count_col = counts.columns[1]
            kept = counts.filter(pl.col(count_col) / len(normalized) >= config.categorical.rare_min_fraction)[c].to_list()
            strategy = config.categorical.overrides.get(c, config.categorical.default_strategy)
            if strategy == "one_hot" and len(kept) > config.categorical.max_one_hot_categories:
                raise ValueError(f"Too many categories for one-hot: {c} ({len(kept)})")
            frequencies = dict(zip(counts[c].to_list(), (counts[count_col] / len(normalized)).to_list()))
            state.categorical[c] = {
                "fill": fill, "known": kept, "strategy": strategy,
                "mapping": {str(value): i for i, value in enumerate(kept)},
                "frequencies": {str(k): v for k, v in frequencies.items()},
            }
    return state


def transform(lf: pl.LazyFrame, state: PipelineState, config: ProjectConfig) -> pl.LazyFrame:
    schema = lf.collect_schema()
    expressions: list[pl.Expr] = []
    drop: list[str] = []
    for c, params in state.numeric.items():
        if c not in schema:
            raise ValueError(f"Missing fitted numeric column: {c}")
        raw = pl.col(c).cast(pl.Float64, strict=False)
        missing = raw.is_null() | raw.is_in([math.inf, -math.inf])
        x = raw.replace([math.inf, -math.inf], None)
        if params["fill"] is not None:
            x = x.fill_null(params["fill"])
        if params["lower"] is not None:
            x = x.clip(lower_bound=params["lower"])
        if params["upper"] is not None:
            x = x.clip(upper_bound=params["upper"])
        if c in config.numeric.log1p:
            x = x.log1p()
        x = (x - params["center"]) / params["scale"]
        dtype = pl.Float32 if config.numeric.dtype == "float32" else pl.Float64
        expressions.append(x.cast(dtype).alias(c))
        if config.missing.add_indicator:
            expressions.append(missing.cast(pl.UInt8).alias(f"{c}__missing"))
        if params["bins"]:
            expressions.append(pl.sum_horizontal([x > value for value in params["bins"]]).cast(pl.UInt16).alias(f"{c}__bin"))

    for c, params in state.categorical.items():
        if c not in schema:
            raise ValueError(f"Missing fitted categorical column: {c}")
        raw = pl.col(c)
        if config.missing.add_indicator:
            expressions.append(raw.is_null().cast(pl.UInt8).alias(f"{c}__missing"))
        x = _category(raw, config)
        if config.missing.categorical != "none":
            x = x.fill_null(params["fill"])
        x = pl.when(x.is_in(params["known"])).then(x).otherwise(pl.lit("__UNKNOWN__"))
        strategy = params["strategy"]
        if strategy == "native":
            expressions.append(x.alias(c))
        elif strategy == "ordinal":
            expressions.append(x.replace_strict(params["mapping"], default=-1).cast(pl.Int32).alias(c))
        elif strategy == "frequency":
            expressions.append(x.replace_strict(params["frequencies"], default=0.0).cast(pl.Float32).alias(c))
        else:
            expressions.extend((x == value).cast(pl.UInt8).alias(f"{c}__oh_{i}") for i, value in enumerate(params["known"]))
            drop.append(c)

    for c, role in state.roles.items():
        if c not in schema:
            continue
        if role == "datetime":
            x = pl.col(c)
            if schema[c] == pl.String:
                x = x.str.to_datetime(strict=False)
            parts = {
                "year": x.dt.year(), "quarter": x.dt.quarter(), "month": x.dt.month(),
                "weekday": x.dt.weekday(), "day": x.dt.day(), "hour": x.dt.hour(),
            }
            expressions.extend(parts[p].alias(f"{c}__{p}") for p in config.datetime.components)
            for p in config.datetime.cyclical:
                period = {"month": 12, "weekday": 7, "hour": 24}[p]
                expressions.extend([
                    (parts[p] * 2 * math.pi / period).sin().alias(f"{c}__{p}_sin"),
                    (parts[p] * 2 * math.pi / period).cos().alias(f"{c}__{p}_cos"),
                ])
            if config.datetime.drop_original:
                drop.append(c)
        elif role == "text" and config.text.enabled:
            x = pl.col(c).cast(pl.String, strict=False).fill_null(config.missing.text_value)
            features = {
                "length": x.str.len_chars(), "words": x.str.count_matches(r"\S+"),
                "digit_ratio": x.str.count_matches(r"\d") / x.str.len_chars().clip(lower_bound=1),
                "special_count": x.str.count_matches(r"[^\w\s]"), "is_empty": x.str.strip_chars().eq(""),
            }
            expressions.extend(features[p].alias(f"{c}__{p}") for p in config.text.features)
            if config.text.drop_original:
                drop.append(c)
    result = lf.with_columns(expressions)
    return result.drop(drop) if drop else result
