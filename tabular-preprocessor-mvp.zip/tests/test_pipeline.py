import json

import polars as pl

from tabular_preprocessor import Pipeline
from tabular_preprocessor.config import (
    CategoricalConfig, InputConfig, NumericConfig, OutputConfig, ProjectConfig,
    SchemaConfig, SplitConfig, TaskConfig,
)


def config(tmp_path, **output):
    return ProjectConfig(
        input=InputConfig(paths=(str(tmp_path / "input.parquet"),)),
        task=TaskConfig(target="target", task_type="binary", id_columns=("id",), date_column="date"),
        output=OutputConfig(path=str(tmp_path / "result"), rows_per_file=2, **output),
        schema=SchemaConfig(explicit_roles={"category": "categorical", "comment": "text"}),
        split=SplitConfig(method="temporal", boundaries=("2024-01-03", "2024-01-04")),
        numeric=NumericConfig(scaling="robust"),
        categorical=CategoricalConfig(default_strategy="ordinal"),
    )


def data():
    return pl.DataFrame({
        "id": [1, 2, 3, 4, 5], "date": ["2024-01-01", "2024-01-02", "2024-01-03", "2024-01-04", "2024-01-05"],
        "value": [1.0, None, 3.0, 100.0, 5.0], "category": ["A", "B", "A", "C", None],
        "comment": ["one", "two", "three", "four", "five"], "target": [0, 1, 0, 1, 0],
    })


def test_end_to_end_and_saved_state(tmp_path):
    source = data()
    source.write_parquet(tmp_path / "input.parquet")
    cfg = config(tmp_path)
    result = Pipeline(cfg).run()
    manifest = json.loads(result.manifest_path.read_text())
    assert manifest["status"] == "success"
    assert manifest["rows"] == 5
    assert result.state_path.exists()
    assert len(list((result.output_path / "data").rglob("*.parquet"))) == 4
    schemas = [pl.read_parquet_schema(path) for path in (result.output_path / "data").rglob("*.parquet")]
    assert all(schema == schemas[0] for schema in schemas)

    fitted = Pipeline.from_state(cfg, result.state_path)
    transformed = fitted.transform(source).collect()
    assert "value__missing" in transformed.columns
    assert "comment__length" in transformed.columns
    assert transformed["category"].dtype == pl.Int32
    assert transformed["category"].to_list()[-2:] == [-1, -1]


def test_group_split_has_no_id_overlap(tmp_path):
    cfg = config(tmp_path)
    cfg = ProjectConfig(
        input=cfg.input, task=cfg.task, output=cfg.output, schema=cfg.schema,
        split=SplitConfig(method="group", group_column="id"),
    )
    lf = Pipeline(cfg).prepare(data())[0]
    overlap = lf.group_by("id").agg(pl.col("sample").n_unique().alias("n")).filter(pl.col("n") > 1).collect()
    assert overlap.is_empty()


def test_missing_required_column(tmp_path):
    cfg = config(tmp_path)
    try:
        Pipeline(cfg).prepare(data().drop("target"))
    except ValueError as error:
        assert "target" in str(error)
    else:
        raise AssertionError("missing target was accepted")


def test_one_hot_schema_is_stable_for_new_category(tmp_path):
    base = config(tmp_path)
    cfg = ProjectConfig(
        input=base.input, task=base.task, output=base.output, schema=base.schema,
        split=base.split, categorical=CategoricalConfig(default_strategy="one_hot"),
    )
    pipeline = Pipeline(cfg)
    pipeline.prepare(data())
    transformed = pipeline.transform(data().with_columns(pl.lit("NEW").alias("category"))).collect()
    assert "category" not in transformed.columns
    assert transformed.select(pl.selectors.starts_with("category__oh_")).sum().row(0) == (0, 0)


def test_overwrite_replaces_complete_output(tmp_path):
    source = data()
    source.write_parquet(tmp_path / "input.parquet")
    Pipeline(config(tmp_path)).run()
    cfg = config(tmp_path, overwrite=True)
    result = Pipeline(cfg).run(source.head(3))
    assert json.loads(result.manifest_path.read_text())["rows"] == 3
    assert not list(tmp_path.glob(".result.tmp-*"))
    assert not list(tmp_path.glob(".result.backup-*"))
