import polars as pl

from tabular_preprocessor.config import InputConfig, SplitConfig, TaskConfig
from tabular_preprocessor.io.reader import read_lazy
from tabular_preprocessor.splitting import split


def test_reads_multiple_parquet_files(tmp_path):
    pl.DataFrame({"x": [1, 2]}).write_parquet(tmp_path / "a.parquet")
    pl.DataFrame({"x": [3]}).write_parquet(tmp_path / "b.parquet")
    lf = read_lazy(InputConfig(paths=(str(tmp_path / "*.parquet"),)))
    assert lf.collect()["x"].to_list() == [1, 2, 3]


def test_existing_split(tmp_path):
    lf = pl.DataFrame({"sample": ["train", "valid"], "x": [1, 2]}).lazy()
    result = split(lf, SplitConfig(method="existing"), TaskConfig()).collect()
    assert result["sample"].to_list() == ["train", "valid"]


def test_temporal_split_boundaries():
    lf = pl.DataFrame({"date": ["2024-01-01", "2024-02-01", "2024-03-01"]}).lazy()
    cfg = SplitConfig(method="temporal", boundaries=("2024-01-31", "2024-02-29"))
    result = split(lf, cfg, TaskConfig(date_column="date")).collect()
    assert result["sample"].to_list() == ["train", "valid", "test"]
