from tabular_preprocessor.config import (
    InputConfig, OutputConfig, ProgressConfig, ProjectConfig, QualityGateConfig,
    SchemaConfig, TaskConfig,
)

CONFIG = ProjectConfig(
    input=InputConfig(
        paths=("/home/datalab/nfs/path/to/split_parts",),
        layout="sample_directories",
        samples=("train", "valid", "oos", "oot"),
    ),
    task=TaskConfig(target="target", id_columns=("appl_num",), date_column="appl_dt"),
    output=OutputConfig(path="/home/datalab/nfs/path/to/prepared_data", overwrite=True),
    schema=SchemaConfig(required_columns=("appl_num", "appl_dt", "target")),
    quality_gates=QualityGateConfig(
        max_invalid_row_rate=.01,
        max_duplicate_rate=.005,
        max_new_category_rate=.03,
    ),
    progress=ProgressConfig(display="auto"),
)
