import bisect
import math

import polars as pl

from ..config import DriftConfig, TaskConfig


def check_drift(
    lf: pl.LazyFrame,
    roles: dict[str, str],
    config: DriftConfig,
    task: TaskConfig,
    sample_column: str,
) -> tuple[pl.DataFrame, pl.DataFrame, list[dict]]:
    if not config.enabled or sample_column not in lf.collect_schema():
        return pl.DataFrame(), pl.DataFrame(), []
    columns = list(config.columns) or [c for c, role in roles.items() if role in {"numeric", "categorical", "ordinal", "binary"}]
    columns = [c for c in columns if c in lf.collect_schema()][:config.max_features]
    df = lf.select(sample_column, *columns, *[c for c in config.segment_columns if c not in columns],
                   *([task.target] if task.target and task.target not in columns else []))
    df = df.group_by(sample_column, maintain_order=True).head(config.max_rows_per_sample).collect(engine="streaming")
    reference = df.filter(pl.col(sample_column) == config.reference_sample)
    rows, issues = [], []
    for comparison_name in config.comparison_samples:
        comparison = df.filter(pl.col(sample_column) == comparison_name)
        if reference.is_empty() or comparison.is_empty():
            continue
        for column in columns:
            if roles[column] == "numeric":
                score = _numeric_psi(reference[column], comparison[column], config.bins)
                metric = "psi"
            else:
                score = _categorical_js(reference[column], comparison[column])
                metric = "jensen_shannon"
            severity = "critical" if score >= config.critical else "warning" if score >= config.warning else "info"
            rows.append({"column": column, "reference_sample": config.reference_sample,
                         "comparison_sample": comparison_name, "metric": metric, "value": score, "severity": severity})
            if severity != "info":
                issues.append({"check": "drift", "severity": severity, "column": column,
                               "sample": comparison_name, "row_id": None, "reason": f"{metric}={score:.4f}",
                               "recommended_action": "review distribution change"})
    segments = _segments(df, config, task, sample_column)
    return pl.DataFrame(rows), segments, issues


def _numeric_psi(reference: pl.Series, comparison: pl.Series, bins: int) -> float:
    ref = sorted(float(x) for x in reference.drop_nulls())
    cur = [float(x) for x in comparison.drop_nulls()]
    if not ref or not cur:
        return 0.0
    edges = sorted(set(ref[min(len(ref) - 1, int(len(ref) * i / bins))] for i in range(1, bins)))
    ref_counts = [0] * (len(edges) + 1)
    cur_counts = [0] * (len(edges) + 1)
    for value in ref:
        ref_counts[bisect.bisect_right(edges, value)] += 1
    for value in cur:
        cur_counts[bisect.bisect_right(edges, value)] += 1
    return _psi(ref_counts, cur_counts)


def _categorical_js(reference: pl.Series, comparison: pl.Series) -> float:
    def distribution(series):
        values = series.cast(pl.String).fill_null("__NULL__")
        return {row[0]: row[1] / len(values) for row in values.value_counts().iter_rows()}
    left, right = distribution(reference), distribution(comparison)
    keys = set(left) | set(right)
    score = 0.0
    for key in keys:
        p, q = left.get(key, 0.0), right.get(key, 0.0)
        middle = (p + q) / 2
        if p:
            score += p * math.log(p / middle) / 2
        if q:
            score += q * math.log(q / middle) / 2
    return score


def _psi(left, right):
    total_left, total_right, epsilon = sum(left), sum(right), 1e-6
    return sum((max(a / total_left, epsilon) - max(b / total_right, epsilon)) *
               math.log(max(a / total_left, epsilon) / max(b / total_right, epsilon))
               for a, b in zip(left, right))


def _segments(df: pl.DataFrame, config: DriftConfig, task: TaskConfig, sample: str) -> pl.DataFrame:
    rows = []
    for column in config.segment_columns:
        if column not in df:
            continue
        expressions = [pl.len().alias("rows")]
        if task.target and task.target in df and df[task.target].dtype.is_numeric():
            expressions.append(pl.col(task.target).mean().alias("target_rate"))
        grouped = df.group_by(sample, column).agg(expressions)
        for row in grouped.iter_rows(named=True):
            rows.append({"segment_column": column, "segment_value": str(row[column]), "sample": str(row[sample]),
                         "rows": row["rows"], "target_rate": row.get("target_rate")})
    return pl.DataFrame(rows) if rows else pl.DataFrame()
