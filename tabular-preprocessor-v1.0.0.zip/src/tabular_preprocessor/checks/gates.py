import polars as pl

from ..config import QualityGateConfig


def evaluate_gates(
    config: QualityGateConfig,
    rows: int,
    row_issues: pl.DataFrame,
    issues: list[dict],
    rules: list[dict],
    duplicate_rate: float,
    new_category_rate: float,
) -> dict:
    quarantined = row_issues.filter(pl.col("action") == "quarantined")["row_id"].n_unique() if row_issues.height else 0
    invalid = row_issues.filter(pl.col("severity").is_in(["error", "critical"]))["row_id"].n_unique() if row_issues.height else 0
    metrics = {
        "invalid_row_rate": invalid / rows if rows else 0.0,
        "duplicate_rate": duplicate_rate,
        "new_category_rate": new_category_rate,
        "quarantined_rows": quarantined,
    }
    checks = [
        _gate("invalid_row_rate", metrics["invalid_row_rate"], config.max_invalid_row_rate),
        _gate("duplicate_rate", duplicate_rate, config.max_duplicate_rate),
        _gate("new_category_rate", new_category_rate, config.max_new_category_rate),
        _gate("quarantined_rows", quarantined, config.max_quarantined_rows),
    ]
    if config.fail_on_schema_error:
        checks.append({"name": "schema_errors", "value": sum(i["severity"] == "critical" for i in issues), "threshold": 0, "passed": not any(i["severity"] == "critical" for i in issues)})
    failed_rules = [r["rule"] for r in rules if not r["passed"] and r["severity"] in {"error", "critical"}]
    checks.append({"name": "blocking_rules", "value": len(failed_rules), "threshold": 0, "passed": not failed_rules, "rules": failed_rules})
    failed = config.enabled and any(not check["passed"] for check in checks)
    warnings = any(i["severity"] == "warning" for i in issues) or any(r["failed_rows"] for r in rules)
    return {"status": "failed_quality_gate" if failed else "passed_with_warnings" if warnings else "passed", "metrics": metrics, "checks": checks}


def _gate(name: str, value: float, threshold: float) -> dict:
    return {"name": name, "value": value, "threshold": threshold, "passed": value <= threshold}
