from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

Role = Literal[
    "numeric", "categorical", "ordinal", "binary", "datetime", "text",
    "id", "target", "technical", "excluded", "unknown",
]


@dataclass(frozen=True)
class InputConfig:
    paths: tuple[str, ...] = ()
    format: Literal["parquet", "csv", "ipc"] = "parquet"
    columns: tuple[str, ...] | None = None
    row_index: str | None = None
    csv_separator: str = ","
    layout: Literal["files", "sample_directories", "sample_paths"] = "files"
    samples: tuple[str, ...] = ()
    sample_paths: dict[str, tuple[str, ...]] = field(default_factory=dict)
    sample_column: str = "sample"
    file_pattern: str = "**/*.parquet"
    checksum: bool = True


@dataclass(frozen=True)
class TaskConfig:
    target: str | None = None
    task_type: Literal["binary", "multiclass", "regression", "unsupervised"] = "unsupervised"
    id_columns: tuple[str, ...] = ()
    date_column: str | None = None
    excluded_columns: tuple[str, ...] = ()


@dataclass(frozen=True)
class OutputConfig:
    path: str
    format: Literal["parquet"] = "parquet"
    partition_columns: tuple[str, ...] = ("sample",)
    compression: str = "zstd"
    rows_per_file: int = 1_000_000
    overwrite: bool = False


@dataclass(frozen=True)
class SchemaConfig:
    explicit_roles: dict[str, Role] = field(default_factory=dict)
    role_patterns: dict[str, Role] = field(default_factory=dict)
    required_columns: tuple[str, ...] = ()
    nullable: dict[str, bool] = field(default_factory=dict)
    ranges: dict[str, tuple[float | None, float | None]] = field(default_factory=dict)
    allowed_values: dict[str, tuple[object, ...]] = field(default_factory=dict)
    casts: dict[str, str] = field(default_factory=dict)
    string_text_length: int = 80
    policy: Literal["exact", "backward", "permissive"] = "permissive"
    expected_schema: dict[str, str] = field(default_factory=dict)
    preserve_column_order: bool = False


@dataclass(frozen=True)
class Rule:
    name: str
    expression: Any
    severity: Literal["info", "warning", "error", "critical"] = "error"
    max_failure_rate: float = 0.0
    action: Literal["keep", "quarantine"] = "quarantine"
    column: str | None = None
    reason: str = "rule violation"


@dataclass(frozen=True)
class RuleConfig:
    rules: tuple[Rule, ...] = ()
    example_rows: int = 10


@dataclass(frozen=True)
class ProfilingConfig:
    enabled: bool = True
    sample_rows: int | None = 100_000
    quantiles: tuple[float, ...] = (0.01, 0.25, 0.5, 0.75, 0.99)
    top_k: int = 10
    missingness: bool = True
    missingness_columns: tuple[str, ...] = ()
    missingness_pairs: tuple[tuple[str, str], ...] = ()
    segment_columns: tuple[str, ...] = ()


@dataclass(frozen=True)
class SplitConfig:
    method: Literal["none", "existing", "random", "stratified", "group", "temporal", "group_temporal"] = "none"
    sample_column: str = "sample"
    allowed_samples: tuple[str, ...] = ("train", "valid", "test")
    fractions: tuple[float, ...] = (0.7, 0.15, 0.15)
    group_column: str | None = None
    date_column: str | None = None
    boundaries: tuple[str, ...] = ()
    seed: int = 42


@dataclass(frozen=True)
class MissingConfig:
    numeric: Literal["median", "mean", "zero", "none"] = "median"
    categorical: Literal["most_frequent", "constant", "none"] = "constant"
    categorical_value: str = "__MISSING__"
    text_value: str = ""
    add_indicator: bool = True


@dataclass(frozen=True)
class NumericConfig:
    dtype: Literal["float32", "float64"] = "float32"
    scaling: Literal["none", "standard", "robust"] = "none"
    winsorize: tuple[float, float] | None = None
    clip: dict[str, tuple[float | None, float | None]] = field(default_factory=dict)
    log1p: tuple[str, ...] = ()
    quantile_bins: dict[str, int] = field(default_factory=dict)


@dataclass(frozen=True)
class CategoricalConfig:
    default_strategy: Literal["native", "ordinal", "frequency", "one_hot"] = "native"
    overrides: dict[str, Literal["native", "ordinal", "frequency", "one_hot"]] = field(default_factory=dict)
    normalize_case: bool = True
    strip: bool = True
    rare_min_fraction: float = 0.0
    max_one_hot_categories: int = 20


@dataclass(frozen=True)
class DatetimeConfig:
    components: tuple[str, ...] = ("year", "month", "weekday")
    cyclical: tuple[str, ...] = ()
    drop_original: bool = False


@dataclass(frozen=True)
class TextConfig:
    enabled: bool = True
    features: tuple[str, ...] = ("length", "words", "digit_ratio", "special_count", "is_empty")
    drop_original: bool = True


@dataclass(frozen=True)
class LeakageConfig:
    enabled: bool = True
    near_constant_fraction: float = 0.995
    check_sample_overlap: bool = True
    check_temporal_order: bool = True


@dataclass(frozen=True)
class DuplicateConfig:
    enabled: bool = True
    key_columns: tuple[str, ...] = ()
    action: Literal["keep", "quarantine"] = "keep"


@dataclass(frozen=True)
class DriftConfig:
    enabled: bool = False
    reference_sample: str = "train"
    comparison_samples: tuple[str, ...] = ("valid", "test", "oos", "oot")
    warning: float = 0.10
    critical: float = 0.25
    bins: int = 10
    max_rows_per_sample: int = 200_000
    segment_columns: tuple[str, ...] = ()
    columns: tuple[str, ...] = ()
    max_features: int = 100


@dataclass(frozen=True)
class QuarantineConfig:
    enabled: bool = True
    schema_violations: bool = True
    rule_violations: bool = True
    trace_transformations: bool = False


@dataclass(frozen=True)
class QualityGateConfig:
    enabled: bool = True
    fail_on_schema_error: bool = True
    max_invalid_row_rate: float = 1.0
    max_duplicate_rate: float = 1.0
    max_new_category_rate: float = 1.0
    max_quarantined_rows: int = 100_000


@dataclass(frozen=True)
class LineageConfig:
    baseline_path: str | None = None
    compare_previous: bool = True


@dataclass(frozen=True)
class ProgressConfig:
    enabled: bool = True
    display: Literal["auto", "none", "console", "jupyter"] = "auto"
    update_interval_seconds: float = 1.0
    persist_events: bool = True


@dataclass(frozen=True)
class ResourceConfig:
    threads: int | None = None
    memory_limit_gb: float | None = None


@dataclass(frozen=True)
class ReportingConfig:
    enabled: bool = True
    html: bool = True


@dataclass(frozen=True)
class ProjectConfig:
    input: InputConfig
    task: TaskConfig
    output: OutputConfig
    schema: SchemaConfig = field(default_factory=SchemaConfig)
    rules: RuleConfig = field(default_factory=RuleConfig)
    profiling: ProfilingConfig = field(default_factory=ProfilingConfig)
    split: SplitConfig = field(default_factory=SplitConfig)
    missing: MissingConfig = field(default_factory=MissingConfig)
    numeric: NumericConfig = field(default_factory=NumericConfig)
    categorical: CategoricalConfig = field(default_factory=CategoricalConfig)
    datetime: DatetimeConfig = field(default_factory=DatetimeConfig)
    text: TextConfig = field(default_factory=TextConfig)
    leakage: LeakageConfig = field(default_factory=LeakageConfig)
    duplicates: DuplicateConfig = field(default_factory=DuplicateConfig)
    drift: DriftConfig = field(default_factory=DriftConfig)
    quarantine: QuarantineConfig = field(default_factory=QuarantineConfig)
    quality_gates: QualityGateConfig = field(default_factory=QualityGateConfig)
    lineage: LineageConfig = field(default_factory=LineageConfig)
    progress: ProgressConfig = field(default_factory=ProgressConfig)
    resources: ResourceConfig = field(default_factory=ResourceConfig)
    reporting: ReportingConfig = field(default_factory=ReportingConfig)

    def validate(self) -> None:
        if self.input.layout == "files" and not self.input.paths:
            raise ValueError("input.paths is empty")
        if self.input.layout == "sample_directories" and (not self.input.paths or not self.input.samples):
            raise ValueError("sample_directories requires input.paths and input.samples")
        if self.input.layout == "sample_paths" and not self.input.sample_paths:
            raise ValueError("sample_paths layout requires input.sample_paths")
        if self.output.rows_per_file < 1:
            raise ValueError("output.rows_per_file must be positive")
        if self.split.method in {"random", "stratified", "group"}:
            if len(self.split.fractions) != len(self.split.allowed_samples):
                raise ValueError("split.fractions and allowed_samples must have equal length")
            if abs(sum(self.split.fractions) - 1) > 1e-9:
                raise ValueError("split.fractions must sum to 1")
        if self.split.method in {"group", "group_temporal"} and not self.split.group_column:
            raise ValueError("group_column is required")
        if self.split.method in {"temporal", "group_temporal"}:
            if not (self.split.date_column or self.task.date_column):
                raise ValueError("date_column is required")
            if len(self.split.boundaries) != len(self.split.allowed_samples) - 1:
                raise ValueError("temporal boundaries count must be samples count minus one")
        if self.split.method == "stratified" and not self.task.target:
            raise ValueError("target is required for stratified split")
        rates = (
            self.quality_gates.max_invalid_row_rate,
            self.quality_gates.max_duplicate_rate,
            self.quality_gates.max_new_category_rate,
        )
        if any(not 0 <= x <= 1 for x in rates):
            raise ValueError("quality gate rates must be between 0 and 1")
        if Path(self.output.path).resolve() in {Path("/").resolve(), Path.home().resolve()}:
            raise ValueError("unsafe output path")
