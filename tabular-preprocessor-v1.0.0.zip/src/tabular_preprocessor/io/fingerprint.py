import hashlib
import json
from pathlib import Path

import polars as pl

from ..config import InputConfig, TaskConfig


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def input_fingerprint(
    lf: pl.LazyFrame,
    config: InputConfig,
    task: TaskConfig,
    discovered: dict[str, list[str]] | None,
) -> dict:
    files = []
    for sample, paths in (discovered or {}).items():
        for raw in paths:
            path = Path(raw)
            stat = path.stat()
            files.append({
                "sample": None if sample == "__all__" else sample,
                "path": str(path.resolve()),
                "bytes": stat.st_size,
                "modified_ns": stat.st_mtime_ns,
                "sha256": _sha256(path) if config.checksum else None,
            })
    schema = {name: str(dtype) for name, dtype in lf.collect_schema().items()}
    exprs = [pl.len().alias("rows")]
    if not discovered:
        exprs.append(pl.struct(pl.all()).hash(seed=0).sum().cast(pl.String).alias("content_hash"))
    if task.date_column and task.date_column in schema:
        date = pl.col(task.date_column)
        exprs += [date.min().cast(pl.String).alias("date_min"), date.max().cast(pl.String).alias("date_max")]
    values = lf.select(exprs).collect().row(0, named=True)
    payload = {"files": files, "schema": schema, **values}
    payload["sha256"] = hashlib.sha256(
        json.dumps(payload, sort_keys=True, ensure_ascii=False, default=str).encode()
    ).hexdigest()
    return payload
