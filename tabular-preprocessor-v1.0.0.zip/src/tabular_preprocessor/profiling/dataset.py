import json

import polars as pl

from ..config import ProfilingConfig, TaskConfig


def profile(
    lf: pl.LazyFrame,
    roles: dict[str, str],
    config: ProfilingConfig,
    task: TaskConfig | None = None,
    sample_column: str = "sample",
) -> tuple[dict, pl.DataFrame, pl.DataFrame]:
    total_rows = lf.select(pl.len()).collect().item()
    sampled = lf.limit(config.sample_rows) if config.sample_rows else lf
    df = sampled.collect(engine="streaming")
    rows = []
    for name in df.columns:
        s = df[name]
        non_null = s.drop_nulls()
        numeric, string = s.dtype.is_numeric(), s.dtype == pl.String
        top = s.value_counts(sort=True).head(config.top_k).to_dicts()
        row = {
            "column": name, "physical_type": str(s.dtype), "role": roles.get(name, "unknown"),
            "rows_profiled": len(s), "null_count": s.null_count(),
            "null_fraction": s.null_count() / len(s) if len(s) else 0.0,
            "n_unique": s.n_unique(), "constant": s.n_unique() <= 1,
            "min": _number(non_null.min()) if numeric and len(non_null) else None,
            "max": _number(non_null.max()) if numeric and len(non_null) else None,
            "mean": _number(non_null.mean()) if numeric and len(non_null) else None,
            "std": _number(non_null.std()) if numeric and len(non_null) > 1 else None,
            "skew": _number(non_null.skew()) if numeric and len(non_null) > 2 else None,
            "min_length": non_null.str.len_chars().min() if string and len(non_null) else None,
            "max_length": non_null.str.len_chars().max() if string and len(non_null) else None,
            "mean_length": _number(non_null.str.len_chars().mean()) if string and len(non_null) else None,
            "empty_fraction": non_null.str.strip_chars().eq("").mean() if string and len(non_null) else None,
            "top_values": json.dumps(top, ensure_ascii=False, default=str),
        }
        for q in config.quantiles:
            row[f"q_{q:g}"] = _number(non_null.quantile(q)) if numeric and len(non_null) else None
        rows.append(row)
    summary = {
        "rows": total_rows, "columns": len(df.columns), "profiled_rows": len(df),
        "estimated_size_bytes_profiled": df.estimated_size(),
        "duplicate_rows_profiled": df.is_duplicated().sum(),
        "duplicate_rate_profiled": float(df.is_duplicated().mean()) if len(df) else 0.0,
        "physical_types": {str(dtype): list(df.schema.values()).count(dtype) for dtype in set(df.schema.values())},
    }
    if task and task.target and task.target in df:
        summary["target_distribution"] = df[task.target].value_counts(sort=True).to_dicts()
    if task and task.date_column and task.date_column in df:
        summary["date_range"] = {"min": str(df[task.date_column].min()), "max": str(df[task.date_column].max())}
    if sample_column in df:
        summary["samples"] = df[sample_column].value_counts(sort=True).to_dicts()
    missing = missingness_profile(df, config, task, sample_column) if config.missingness else pl.DataFrame()
    return summary, pl.DataFrame(rows), missing


def missingness_profile(df: pl.DataFrame, config: ProfilingConfig, task: TaskConfig | None, sample: str) -> pl.DataFrame:
    columns = [c for c in (config.missingness_columns or tuple(df.columns)) if c in df.columns and c != sample]
    rows = []
    for column in columns:
        nulls = df[column].is_null()
        row = {"kind": "column", "column": column, "column_2": None, "sample": None,
               "pattern": None, "rows": len(df), "value": int(nulls.sum()), "rate": float(nulls.mean())}
        if task and task.target and task.target in df and df[task.target].dtype.is_numeric():
            row["target_rate_missing"] = _number(df.filter(nulls)[task.target].mean())
            row["target_rate_present"] = _number(df.filter(~nulls)[task.target].mean())
        rows.append(row)
        if sample in df:
            for values in df.group_by(sample).agg(pl.col(column).is_null().sum().alias("value"), pl.len().alias("rows")).iter_rows(named=True):
                rows.append({"kind": "sample", "column": column, "column_2": None, "sample": str(values[sample]),
                             "pattern": None, "rows": values["rows"], "value": values["value"],
                             "rate": values["value"] / values["rows"] if values["rows"] else 0.0})
    for first, second in config.missingness_pairs:
        if first in df and second in df:
            value = int((df[first].is_null() & df[second].is_null()).sum())
            rows.append({"kind": "pair", "column": first, "column_2": second, "sample": None,
                         "pattern": None, "rows": len(df), "value": value, "rate": value / len(df) if len(df) else 0.0})
    if columns:
        pattern = df.select([pl.when(pl.col(c).is_null()).then(pl.lit(c)).otherwise(pl.lit(None)).alias(c) for c in columns])
        pattern = pattern.select(pl.concat_list(pl.all()).list.drop_nulls().list.join("|").alias("pattern"))
        for values in pattern.group_by("pattern").len().sort("len", descending=True).head(config.top_k).iter_rows(named=True):
            rows.append({"kind": "pattern", "column": None, "column_2": None, "sample": None,
                         "pattern": values["pattern"], "rows": len(df), "value": values["len"],
                         "rate": values["len"] / len(df) if len(df) else 0.0})
    return pl.DataFrame(rows, infer_schema_length=None) if rows else pl.DataFrame()


def _number(value):
    return float(value) if value is not None else None
