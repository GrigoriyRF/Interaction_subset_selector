from dataclasses import asdict, dataclass, field
from time import perf_counter
from typing import Any, Callable, Literal

from ..config import ProgressConfig


@dataclass(frozen=True)
class ProgressEvent:
    stage: str
    status: Literal["started", "running", "completed", "failed"]
    current: int | None = None
    total: int | None = None
    message: str = ""
    elapsed_seconds: float = 0.0
    sample: str | None = None
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        row = asdict(self)
        row["details"] = str(row["details"])
        return row


class ConsoleProgress:
    def __call__(self, event: ProgressEvent) -> None:
        suffix = f" [{event.sample}]" if event.sample else ""
        count = f" {event.current}/{event.total}" if event.total is not None else ""
        print(f"{event.status:9} {event.message or event.stage}{suffix}{count} ({event.elapsed_seconds:.1f}s)")


class JupyterProgress:
    def __init__(self) -> None:
        from IPython.display import HTML, display
        self.HTML = HTML
        self.handle = display(HTML("Подготовка запуска…"), display_id=True)

    def __call__(self, event: ProgressEvent) -> None:
        color = {"failed": "#c62828", "completed": "#2e7d32"}.get(event.status, "#3065ac")
        sample = f" · {event.sample}" if event.sample else ""
        count = f" · {event.current}/{event.total}" if event.total is not None else ""
        self.handle.update(self.HTML(
            f"<b style='color:{color}'>{event.message or event.stage}</b>{sample}{count}"
            f"<br><small>{event.status} · {event.elapsed_seconds:.1f} s</small>"
        ))


def _default_callback(config: ProgressConfig):
    if not config.enabled or config.display == "none":
        return None
    display = config.display
    if display == "auto":
        try:
            from IPython import get_ipython
            display = "jupyter" if get_ipython() and "IPKernelApp" in get_ipython().config else "none"
        except Exception:
            display = "none"
    return JupyterProgress() if display == "jupyter" else ConsoleProgress() if display == "console" else None


class ProgressTracker:
    def __init__(self, config: ProgressConfig, callback: Callable[[ProgressEvent], None] | None = None):
        self.callback = callback or _default_callback(config)
        self.enabled = config.enabled
        self.persist = config.persist_events
        self.events: list[ProgressEvent] = []
        self.run_started = perf_counter()
        self.stage_started: dict[str, float] = {}

    def emit(self, stage: str, status: str, message: str = "", **kwargs) -> ProgressEvent:
        now = perf_counter()
        if status == "started":
            self.stage_started[stage] = now
        elapsed = now - self.stage_started.get(stage, self.run_started)
        event = ProgressEvent(stage, status, message=message, elapsed_seconds=elapsed, **kwargs)
        if self.persist:
            self.events.append(event)
        if self.enabled and self.callback:
            try:
                self.callback(event)
            except Exception:
                pass
        return event

    def start(self, stage: str, message: str, **kwargs) -> None:
        self.emit(stage, "started", message, **kwargs)

    def complete(self, stage: str, message: str, **kwargs) -> None:
        self.emit(stage, "completed", message, **kwargs)

    def fail(self, stage: str, error: Exception) -> None:
        self.emit(stage, "failed", f"{type(error).__name__}: {error}", details={"error": type(error).__name__})

    def rows(self) -> list[dict]:
        return [event.to_dict() for event in self.events]

    def durations(self) -> dict[str, float]:
        return {event.stage: event.elapsed_seconds for event in self.events if event.status == "completed"}
