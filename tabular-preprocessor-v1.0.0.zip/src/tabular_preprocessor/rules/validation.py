import json

import polars as pl

from ..config import ProjectConfig, Rule

ROW_ISSUE_SCHEMA = {
    "row_id": pl.String, "sample": pl.String, "column": pl.String,
    "original_value": pl.String, "final_value": pl.String, "rule": pl.String,
    "reason": pl.String, "severity": pl.String, "action": pl.String,
}


def _schema_rules(config: ProjectConfig) -> list[Rule]:
    action = "quarantine" if config.quarantine.schema_violations else "keep"
    rules = []
    for column, nullable in config.schema.nullable.items():
        if not nullable:
            rules.append(Rule(f"schema.not_null.{column}", pl.col(column).is_not_null(), "error", 0, action, column, "null is not allowed"))
    for column, (lower, upper) in config.schema.ranges.items():
        expr = pl.col(column).is_null()
        if lower is not None:
            expr |= pl.col(column) >= lower
        if upper is not None:
            expr &= pl.col(column).is_null() | (pl.col(column) <= upper)
        rules.append(Rule(f"schema.range.{column}", expr, "error", 0, action, column, "value outside allowed range"))
    for column, values in config.schema.allowed_values.items():
        expr = pl.col(column).is_null() | pl.col(column).is_in(values)
        rules.append(Rule(f"schema.allowed.{column}", expr, "error", 0, action, column, "value outside allowed domain"))
    return rules


def evaluate_rules(
    lf: pl.LazyFrame,
    config: ProjectConfig,
    row_id: str,
    sample: str,
) -> tuple[list[dict], pl.DataFrame, pl.Expr]:
    rules = _schema_rules(config) + list(config.rules.rules)
    if not rules:
        return [], pl.DataFrame(schema=ROW_ISSUE_SCHEMA), pl.lit(False)
    expressions = [pl.len().alias("__rows")]
    invalid = []
    for i, rule in enumerate(rules):
        condition = rule.expression.fill_null(False)
        invalid.append(~condition)
        expressions.append((~condition).sum().alias(f"__failed_{i}"))
    counts = lf.select(expressions).collect().row(0, named=True)
    reports, issue_frames = [], []
    quarantine = pl.lit(False)
    for i, (rule, failed) in enumerate(zip(rules, invalid)):
        failed_rows, checked = counts[f"__failed_{i}"], counts["__rows"]
        rate = failed_rows / checked if checked else 0.0
        ids = lf.filter(failed).select(pl.col(row_id).cast(pl.String)).limit(config.rules.example_rows).collect().to_series().to_list()
        reports.append({
            "rule": rule.name, "severity": rule.severity, "sample": None,
            "checked_rows": checked, "failed_rows": failed_rows, "failure_rate": rate,
            "max_failure_rate": rule.max_failure_rate, "example_row_ids": json.dumps(ids),
            "action": rule.action, "passed": rate <= rule.max_failure_rate,
        })
        if not failed_rows:
            continue
        action = "quarantined" if rule.action == "quarantine" and config.quarantine.enabled else "kept"
        original = pl.col(rule.column).cast(pl.String) if rule.column else pl.lit(None, dtype=pl.String)
        sample_expr = pl.col(sample).cast(pl.String) if sample in lf.collect_schema() else pl.lit(None, dtype=pl.String)
        issue_frames.append(lf.filter(failed).select(
            pl.col(row_id).cast(pl.String).alias("row_id"), sample_expr.alias("sample"),
            pl.lit(rule.column, dtype=pl.String).alias("column"), original.alias("original_value"),
            pl.lit(None, dtype=pl.String).alias("final_value"), pl.lit(rule.name).alias("rule"),
            pl.lit(rule.reason).alias("reason"), pl.lit(rule.severity).alias("severity"),
            pl.lit(action).alias("action"),
        ))
        if action == "quarantined":
            quarantine |= failed
    row_issues = pl.concat(issue_frames).collect(engine="streaming") if issue_frames else pl.DataFrame(schema=ROW_ISSUE_SCHEMA)
    return reports, row_issues, quarantine
