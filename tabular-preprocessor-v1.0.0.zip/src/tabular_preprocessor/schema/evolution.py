from ..config import SchemaConfig


def compare_schema(current: dict[str, str], expected: dict[str, str], config: SchemaConfig) -> list[dict]:
    if not expected:
        return []
    issues = []
    current_names, expected_names = list(current), list(expected)
    changes = [
        ("missing_column", name, f"column disappeared (expected {expected[name]})")
        for name in expected_names if name not in current
    ] + [
        ("new_column", name, f"new column ({current[name]})")
        for name in current_names if name not in expected
    ] + [
        ("type_change", name, f"type changed: {expected[name]} -> {current[name]}")
        for name in expected_names if name in current and current[name] != expected[name]
    ]
    if config.preserve_column_order and current_names != expected_names:
        changes.append(("column_order", None, "column order changed"))
    for check, column, reason in changes:
        blocking = config.policy == "exact" or config.policy == "backward" and check != "new_column"
        issues.append({
            "check": check, "severity": "critical" if blocking else "warning",
            "column": column, "sample": None, "row_id": None, "reason": reason,
            "recommended_action": "update schema contract or input data",
        })
    return issues
