import polars as pl

from ..config import SchemaConfig, TaskConfig


def validate_schema(lf: pl.LazyFrame, config: SchemaConfig, task: TaskConfig) -> tuple[pl.LazyFrame, list[dict]]:
    schema = lf.collect_schema()
    required = set(config.required_columns) | set(task.id_columns)
    required |= {c for c in (task.target, task.date_column) if c}
    missing = sorted(required - set(schema.names()))
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    casts = []
    for column, dtype_name in config.casts.items():
        if column not in schema:
            raise ValueError(f"Cannot cast missing column: {column}")
        dtype = getattr(pl, dtype_name, None)
        if dtype is None:
            raise ValueError(f"Unknown Polars dtype: {dtype_name}")
        casts.append(pl.col(column).cast(dtype, strict=False))
    if casts:
        lf = lf.with_columns(casts)

    issues: list[dict] = []
    for column, nullable in config.nullable.items():
        if column in schema and not nullable:
            count = lf.select(pl.col(column).null_count()).collect().item()
            if count:
                issues.append(_issue("nullability", "critical", column, f"{count} null values", "fill or remove nulls"))
    for column, (lower, upper) in config.ranges.items():
        if column in schema:
            condition = pl.lit(False)
            if lower is not None:
                condition |= pl.col(column) < lower
            if upper is not None:
                condition |= pl.col(column) > upper
            count = lf.select(condition.sum()).collect().item()
            if count:
                issues.append(_issue("range", "warning", column, f"{count} values outside range", "review or clip"))
    for column, values in config.allowed_values.items():
        if column in schema:
            count = lf.select((~pl.col(column).is_in(values) & pl.col(column).is_not_null()).sum()).collect().item()
            if count:
                issues.append(_issue("allowed_values", "warning", column, f"{count} unknown values", "review mapping"))
    return lf, issues


def _issue(check: str, severity: str, column: str, reason: str, action: str) -> dict:
    return {
        "check": check, "severity": severity, "column": column, "sample": None,
        "row_id": None, "reason": reason, "recommended_action": action,
    }
