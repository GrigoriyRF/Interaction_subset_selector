import math

import polars as pl

from ..config import ProjectConfig
from .core import _category
from .state import PipelineState


def transformation_issues(
    lf: pl.LazyFrame,
    state: PipelineState,
    config: ProjectConfig,
    row_id: str,
    sample: str,
) -> pl.DataFrame:
    if not config.quarantine.trace_transformations:
        return pl.DataFrame()
    frames = []
    sample_expr = pl.col(sample).cast(pl.String) if sample in lf.collect_schema() else pl.lit(None, dtype=pl.String)
    for column, params in state.numeric.items():
        raw = pl.col(column).cast(pl.Float64, strict=False)
        missing = raw.is_null() | raw.is_in([math.inf, -math.inf])
        clean = raw.replace([math.inf, -math.inf], None)
        final = clean.fill_null(params["fill"]) if params["fill"] is not None else clean
        clipped = pl.lit(False)
        if params["lower"] is not None:
            clipped |= clean < params["lower"]
            final = final.clip(lower_bound=params["lower"])
        if params["upper"] is not None:
            clipped |= clean > params["upper"]
            final = final.clip(upper_bound=params["upper"])
        if column in config.numeric.log1p:
            final = final.log1p()
        final = (final - params["center"]) / params["scale"]
        changed = missing | clipped
        frames.append(lf.filter(changed).select(
            pl.col(row_id).cast(pl.String).alias("row_id"), sample_expr.alias("sample"), pl.lit(column).alias("column"),
            pl.col(column).cast(pl.String).alias("original_value"), final.cast(pl.String).alias("final_value"),
            pl.when(missing).then(pl.lit(f"transform.impute.{column}")).otherwise(pl.lit(f"transform.clip.{column}")).alias("rule"),
            pl.when(missing).then(pl.lit("missing or infinite numeric value")).otherwise(pl.lit("numeric value outside fitted bounds")).alias("reason"),
            pl.lit("info").alias("severity"), pl.when(missing).then(pl.lit("replaced")).otherwise(pl.lit("clipped")).alias("action"),
        ))
    for column, params in state.categorical.items():
        raw = pl.col(column)
        normalized = _category(raw, config)
        filled = normalized.fill_null(params["fill"]) if config.missing.categorical != "none" else normalized
        final = pl.when(filled.is_in(params["known"])).then(filled).otherwise(pl.lit("__UNKNOWN__"))
        changed = raw.is_null() | (raw.cast(pl.String, strict=False) != final).fill_null(False)
        frames.append(lf.filter(changed).select(
            pl.col(row_id).cast(pl.String).alias("row_id"), sample_expr.alias("sample"), pl.lit(column).alias("column"),
            raw.cast(pl.String).alias("original_value"), final.cast(pl.String).alias("final_value"),
            pl.lit(f"transform.category.{column}").alias("rule"), pl.lit("category normalized, filled or mapped").alias("reason"),
            pl.lit("info").alias("severity"), pl.lit("replaced").alias("action"),
        ))
    return pl.concat(frames).collect(engine="streaming") if frames else pl.DataFrame()
