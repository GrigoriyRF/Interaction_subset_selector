# Tabular Preprocessor 1.0.1

Polars-native пайплайн подготовки табличных данных. Версия 1 читает готовые
выборки, проверяет схему и правила, отделяет карантин, применяет quality gates,
фиксирует fingerprint и lineage, рассчитывает drift и сохраняет полный набор
машиночитаемых отчётов.

## Установка

```bash
pip install --no-deps dist/tabular_preprocessor-1.0.1-py3-none-any.whl
```

Требуется `polars>=1.44`. Для разработки: `pip install -e .[dev]`.

## Запуск в Jupyter

```python
from tabular_preprocessor import Pipeline
from tabular_preprocessor.config import *

CONFIG = ProjectConfig(
    input=InputConfig(
        paths=("/data/split_parts",),
        layout="sample_directories",
        samples=("train", "valid", "oos", "oot"),
    ),
    task=TaskConfig(
        target="target",
        id_columns=("appl_num",),
        date_column="appl_dt",
    ),
    output=OutputConfig(
        path="/data/prepared_data",
        rows_per_file=500_000,
        overwrite=True,
    ),
    schema=SchemaConfig(
        required_columns=("appl_num", "appl_dt", "target"),
        policy="permissive",
    ),
    quality_gates=QualityGateConfig(
        max_invalid_row_rate=.01,
        max_duplicate_rate=.005,
        max_new_category_rate=.03,
        max_quarantined_rows=100_000,
    ),
    progress=ProgressConfig(display="jupyter"),
)

result = Pipeline(CONFIG).run()
result
```

Пайплайн сам рекурсивно найдёт Parquet-файлы в `train`, `valid`, `oos`, `oot`,
добавит `sample`, рассчитает state только на `train` и применит его к остальным
выборкам. `SplitConfig(method="existing")` вручную задавать не нужно.

Строковые категориальные колонки с числом уникальных значений выше
`SchemaConfig.max_categorical_cardinality` автоматически получают роль
`excluded` и не участвуют в преобразованиях, drift и проверке новых категорий.
Порог по умолчанию — 1000; явная роль в `explicit_roles` имеет приоритет.

Для нестандартной структуры:

```python
InputConfig(
    layout="sample_paths",
    sample_paths={
        "train": ("/data/development/**/*.parquet",),
        "valid": ("/data/validation/**/*.parquet",),
        "oos": ("/data/oos/**/*.parquet",),
        "oot": ("/data/oot/**/*.parquet",),
    },
)
```

## Межколоночные правила

```python
import polars as pl

RuleConfig(rules=(
    Rule(
        name="valid_period",
        expression=pl.col("end_date") >= pl.col("start_date"),
        severity="error",
        max_failure_rate=.001,
        action="quarantine",
    ),
))
```

Нарушения записываются в `reports/rules.parquet` и
`reports/row_issues.parquet`; отклонённые строки — в `quarantine/`.

## Результат

```text
prepared_data/
├── data/sample=.../*.parquet
├── quarantine/
├── state/
├── reports/
│   ├── report.html
│   ├── profile.parquet
│   ├── missingness.parquet
│   ├── issues.parquet
│   ├── row_issues.parquet
│   ├── rules.parquet
│   ├── drift.parquet
│   ├── quality_gates.json
│   └── run_timeline.parquet
└── manifest.json
```

Статусы: `passed`, `passed_with_warnings`, `failed_quality_gate`,
`failed_runtime`. При непройденном gate отчёты и карантин сохраняются, но
`data/` не публикуется. Если успешный результат уже существует, неуспешный
прогон сохраняется рядом в каталоге `prepared_data.failed-<run_id>`, а предыдущий
успешный результат остаётся на месте.

Повторное применение состояния:

```python
pipeline = Pipeline.from_state(CONFIG, "prepared_data/state/pipeline_state.json")
prepared = pipeline.transform(new_data)
```

Построчный аудит всех импутаций, нормализаций и clipping включается через
`QuarantineConfig(trace_transformations=True)`. По умолчанию он выключен, чтобы
не создавать огромный `row_issues.parquet` на больших датасетах.
