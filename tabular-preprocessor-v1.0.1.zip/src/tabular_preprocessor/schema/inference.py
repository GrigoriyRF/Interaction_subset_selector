import re

import polars as pl

from ..config import Role, SchemaConfig, TaskConfig


def infer_roles(lf: pl.LazyFrame, config: SchemaConfig, task: TaskConfig) -> dict[str, Role]:
    schema = lf.collect_schema()
    string_cols = [name for name, dtype in schema.items() if dtype == pl.String]
    string_stats: dict[str, tuple[int, float]] = {}
    if string_cols:
        expressions = [expr for c in string_cols for expr in (
            pl.col(c).n_unique().alias(f"{c}__n"),
            pl.col(c).str.len_chars().mean().fill_null(0).alias(f"{c}__len"),
        )]
        row = lf.limit(100_000).select(expressions).collect()
        string_stats = {c: (row.item(0, f"{c}__n"), row.item(0, f"{c}__len")) for c in string_cols}

    roles: dict[str, Role] = {}
    for name, dtype in schema.items():
        if name in config.explicit_roles:
            roles[name] = config.explicit_roles[name]
        elif name == task.target:
            roles[name] = "target"
        elif name in task.id_columns:
            roles[name] = "id"
        elif name == task.date_column:
            roles[name] = "datetime"
        elif name in task.excluded_columns:
            roles[name] = "excluded"
        else:
            match = next((role for pattern, role in config.role_patterns.items() if re.search(pattern, name)), None)
            if match:
                roles[name] = match
            elif dtype.is_temporal():
                roles[name] = "datetime"
            elif dtype == pl.Boolean:
                roles[name] = "binary"
            elif dtype.is_numeric():
                roles[name] = "numeric"
            elif dtype == pl.String:
                unique, mean_length = string_stats[name]
                if unique <= 2:
                    roles[name] = "binary"
                elif mean_length >= config.string_text_length:
                    roles[name] = "text"
                elif config.max_categorical_cardinality is not None and unique > config.max_categorical_cardinality:
                    roles[name] = "excluded"
                else:
                    roles[name] = "categorical"
            else:
                roles[name] = "unknown"
    return roles
