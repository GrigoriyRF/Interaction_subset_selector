import json
from dataclasses import replace

import polars as pl

from tabular_preprocessor import Pipeline
from tabular_preprocessor.config import (
    DriftConfig, InputConfig, OutputConfig, ProgressConfig, ProjectConfig,
    QualityGateConfig, Rule, RuleConfig, SchemaConfig, TaskConfig,
)
from tabular_preprocessor.io import discover_inputs, input_fingerprint, read_lazy
from tabular_preprocessor.schema import infer_roles


def _samples(tmp_path, negative=False):
    values = {"train": [1, -2 if negative else 2], "valid": [3], "oos": [4], "oot": [5]}
    for sample, rows in values.items():
        path = tmp_path / "split" / sample / "parts"
        path.mkdir(parents=True)
        pl.DataFrame({"id": rows, "x": [float(x) for x in rows], "category": ["A"] * len(rows), "target": [0] * len(rows)}).write_parquet(path / "part.parquet")


def _config(tmp_path, **kwargs):
    return ProjectConfig(
        input=InputConfig(paths=(str(tmp_path / "split"),), layout="sample_directories", samples=("train", "valid", "oos", "oot")),
        task=TaskConfig(target="target", id_columns=("id",)),
        output=OutputConfig(path=str(tmp_path / "output"), rows_per_file=2, overwrite=kwargs.get("overwrite", False)),
        schema=kwargs.get("schema", SchemaConfig(explicit_roles={"category": "categorical"})),
        rules=kwargs.get("rules", RuleConfig()),
        drift=kwargs.get("drift", DriftConfig()),
        quality_gates=kwargs.get("quality_gates", QualityGateConfig()),
        progress=ProgressConfig(display="none"),
    )


def test_sample_directories_are_loaded_recursively_and_preserved(tmp_path):
    _samples(tmp_path)
    events = []
    result = Pipeline(_config(tmp_path), progress_callback=events.append).run()
    assert result.status in {"passed", "passed_with_warnings"}
    assert {path.parent.name for path in (result.output_path / "data").rglob("*.parquet")} == {"sample=train", "sample=valid", "sample=oos", "sample=oot"}
    completed = {event.stage for event in events if event.status == "completed"}
    assert {"transform_train", "transform_valid", "transform_oos", "transform_oot"} <= completed
    timeline = pl.read_parquet(result.output_path / "reports/run_timeline.parquet")
    assert "quality_gates" in timeline["stage"].to_list()


def test_sample_paths_and_clear_missing_sample_error(tmp_path):
    _samples(tmp_path)
    paths = {sample: (str(tmp_path / "split" / sample / "**/*.parquet"),) for sample in ("train", "valid", "oos", "oot")}
    config = InputConfig(layout="sample_paths", sample_paths=paths)
    assert read_lazy(config).group_by("sample").len().collect().height == 4
    paths["oot"] = (str(tmp_path / "absent/**/*.parquet"),)
    try:
        discover_inputs(InputConfig(layout="sample_paths", sample_paths=paths))
    except FileNotFoundError as error:
        assert "oot" in str(error) and "absent" in str(error)
    else:
        raise AssertionError("empty sample was accepted")


def test_rule_quarantine_failed_gate_keeps_diagnostics(tmp_path):
    _samples(tmp_path, negative=True)
    rule = Rule("positive_x", pl.col("x") > 0, max_failure_rate=0, action="quarantine")
    result = Pipeline(_config(tmp_path, rules=RuleConfig((rule,)), quality_gates=QualityGateConfig(max_invalid_row_rate=1))).run()
    assert result.status == "failed_quality_gate"
    assert not (result.output_path / "data").exists()
    assert (result.output_path / "quarantine/invalid_rules/part-00000.parquet").exists()
    row_issues = pl.read_parquet(result.output_path / "reports/row_issues.parquet")
    assert row_issues.filter(pl.col("rule") == "positive_x")["action"].to_list() == ["quarantined"]
    assert json.loads((result.output_path / "reports/quality_gates.json").read_text())["status"] == "failed_quality_gate"


def test_schema_evolution_and_previous_run_comparison(tmp_path):
    _samples(tmp_path)
    first = Pipeline(_config(tmp_path)).run()
    for path in (tmp_path / "split").rglob("*.parquet"):
        pl.read_parquet(path).with_columns(pl.lit(1).alias("new_column")).write_parquet(path)
    cfg = _config(tmp_path, overwrite=True, schema=SchemaConfig(explicit_roles={"category": "categorical"}, policy="exact"))
    second = Pipeline(cfg).run()
    assert first.output_path == tmp_path / "output"
    assert second.status == "failed_quality_gate"
    assert second.output_path != first.output_path
    assert (first.output_path / "data").exists()
    manifest = json.loads(second.manifest_path.read_text())
    assert manifest["baseline"]["baseline_run_id"]
    assert any(row["check"] == "new_column" for row in pl.read_parquet(second.output_path / "reports/issues.parquet").to_dicts())


def test_fingerprint_is_stable_and_callback_failure_is_ignored(tmp_path):
    _samples(tmp_path)
    input_config = _config(tmp_path).input
    found = discover_inputs(input_config)
    lf = read_lazy(input_config, discovered=found)
    first = input_fingerprint(lf, input_config, TaskConfig(), found)
    second = input_fingerprint(lf, input_config, TaskConfig(), found)
    assert first["sha256"] == second["sha256"]
    result = Pipeline(_config(tmp_path), progress_callback=lambda event: (_ for _ in ()).throw(RuntimeError("display failed"))).run()
    assert result.status in {"passed", "passed_with_warnings"}


def test_univariate_and_segment_drift_report(tmp_path):
    _samples(tmp_path)
    oot = next((tmp_path / "split/oot").rglob("*.parquet"))
    pl.read_parquet(oot).with_columns(pl.lit(1000.0).alias("x")).write_parquet(oot)
    drift = DriftConfig(enabled=True, comparison_samples=("oot",), warning=0.01, segment_columns=("category",))
    result = Pipeline(_config(tmp_path, drift=drift)).run()
    report = pl.read_parquet(result.output_path / "reports/drift.parquet")
    assert report.filter((pl.col("column") == "x") & (pl.col("comparison_sample") == "oot")).height == 1


def test_runtime_failure_keeps_failed_manifest(tmp_path):
    _samples(tmp_path)
    cfg = _config(tmp_path, schema=SchemaConfig(required_columns=("absent",)))
    pipeline = Pipeline(cfg)
    try:
        pipeline.run()
    except ValueError as error:
        assert "absent" in str(error)
    else:
        raise AssertionError("runtime failure was hidden")
    assert pipeline.last_failed_path is not None
    manifest = json.loads((pipeline.last_failed_path / "manifest.json").read_text())
    assert manifest["status"] == "failed_runtime"
    assert manifest["failed_stage"] == "schema_validation"


def test_high_cardinality_string_is_automatically_excluded():
    frame = pl.DataFrame({
        "id": range(1_501),
        "external_code": [f"code-{i}" for i in range(1_501)],
        "category": [f"group-{i % 10}" for i in range(1_501)],
        "target": [i % 2 for i in range(1_501)],
    }).lazy()
    roles = infer_roles(frame, SchemaConfig(), TaskConfig(target="target", id_columns=("id",)))
    assert roles["external_code"] == "excluded"
    assert roles["category"] == "categorical"


def test_explicit_role_overrides_high_cardinality_exclusion():
    frame = pl.DataFrame({"value": [f"code-{i}" for i in range(1_501)]}).lazy()
    roles = infer_roles(frame, SchemaConfig(explicit_roles={"value": "categorical"}), TaskConfig())
    assert roles["value"] == "categorical"


def test_critical_drift_is_not_counted_as_schema_error():
    from tabular_preprocessor.checks import evaluate_gates

    issues = [{"check": "drift", "severity": "critical"}]
    gates = evaluate_gates(QualityGateConfig(), 10, pl.DataFrame(), issues, [], 0.0, 0.0)
    schema_gate = next(check for check in gates["checks"] if check["name"] == "schema_errors")
    assert schema_gate == {"name": "schema_errors", "value": 0, "threshold": 0, "passed": True}
    assert gates["status"] == "passed"
